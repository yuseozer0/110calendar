export const dynamic = 'force-dynamic'

export function GET() {
  const source = `
const CACHE_NAME = '110calendar-v3';
const APP_SHELL = ['/', '/manifest.webmanifest', '/app-icon-192.png', '/app-icon-512.png'];

function readPushPayload(event) {
  if (!event.data) return {};
  try {
    return event.data.json();
  } catch {
    try {
      return { notification: { body: event.data.text() } };
    } catch {
      return {};
    }
  }
}

function resolveNotification(payload) {
  const notification = payload.notification || payload.webpush?.notification || {};
  const data = payload.data || {};
  return {
    title: notification.title || data.title || '110 캘린더',
    options: {
      body: notification.body || data.body || '새로운 일정 소식이 있어요.',
      icon: notification.icon || '/app-icon-192.png',
      badge: notification.badge || '/app-icon-192.png',
      tag: notification.tag || (data.scheduleId ? \`schedule-\${data.scheduleId}\` : '110calendar-update'),
      data: {
        url: payload.fcmOptions?.link || payload.webpush?.fcmOptions?.link || '/',
        scheduleId: data.scheduleId || '',
        category: data.category || '',
      },
      requireInteraction: notification.requireInteraction === true || notification.requireInteraction === 'true',
    },
  };
}

self.addEventListener('push', (event) => {
  const payload = readPushPayload(event);
  const resolved = resolveNotification(payload);
  event.waitUntil(self.registration.showNotification(resolved.title, resolved.options));
});

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put('/', copy));
          return response;
        })
        .catch(() => caches.match('/'))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => cached || fetch(request).then((response) => {
      if (response.ok) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
      }
      return response;
    }))
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      const existing = windowClients.find((client) => client.url.startsWith(self.location.origin));
      return existing ? existing.focus() : clients.openWindow(targetUrl);
    })
  );
});
`

  return new Response(source, {
    headers: {
      'Content-Type': 'application/javascript; charset=utf-8',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Service-Worker-Allowed': '/',
    },
  })
}
